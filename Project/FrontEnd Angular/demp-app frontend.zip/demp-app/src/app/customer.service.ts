import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { Customer } from './customer.model';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { catchError } from 'rxjs/operators';


@Injectable({
  providedIn: 'root'
})

export class CustomerService {

  private empUrl = "http://localhost:53943/api/Customer/";
  constructor(private http:HttpClient) { } 
 
  httpOptions = {
    headers: new HttpHeaders({
       'Content-Type': 'application/json',  
       'accept': 'application/json',    
      })
  };

 //Get all Customers
  getCustomers():Observable<any>{
    return this.http.get<any>(this.empUrl+"GetCustomer").pipe(
      catchError(this.handleError<any>('GetCustomer'))
    );   
       
  }

  //Get particular Customer
  getCustomer(id: number): Observable<any> {
    const url = `${this.empUrl+"SelectCustomerById?id="}${id}`;
    return this.http.get<any>(url).pipe(      
      catchError(this.handleError<any>(`SelectCustomerById id=${id}`))
    );
  }

  //Add Customer
  addCustomer(emp: Customer): Observable<any> {
    console.warn(this.empUrl+"InsertCustomer");
    return this.http.post<any>(this.empUrl+"InsertCustomer", emp, this.httpOptions).pipe(      
      catchError(this.handleError<any>('InsertCustomer'))
    );
  }
  
  //Delete Customer
  deleteCustomer(id: number): Observable<any> {
    const url = `${this.empUrl+"DeleteCustomer?id="}${id}`;

    return this.http.delete<any>(url, this.httpOptions).pipe(      
      catchError(this.handleError<any>('DeleteCustomer'))
    );
  }

  //Update Customer
  updateCustomer(emp: Customer): Observable<any> {
    return this.http.post<any>(this.empUrl+"UpdateCustomer", emp, this.httpOptions).pipe(      
      catchError(this.handleError<any>('UpdateCustomer'))
    );
  }

  //Form handle the errors in the catch section
  private handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {

      
      console.error(error); // log to console instead     

      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
  }
}
