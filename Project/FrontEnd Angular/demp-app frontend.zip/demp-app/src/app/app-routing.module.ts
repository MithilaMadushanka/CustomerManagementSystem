import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { CreateCustomerComponent } from './create-customer/create-customer.component';
import { ViewCustomerComponent } from './view-customer/view-customer.component';
import { CustomerComponent } from './customer/customer.component';
import { AppComponent } from './app.component';


const routes: Routes = [    
  {path: "createCustomer", component:CreateCustomerComponent},
  {path: "viewCustomer", component:ViewCustomerComponent},
  {path: "customer", component:CustomerComponent},  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
