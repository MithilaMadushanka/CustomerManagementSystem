export class Customer {
    id:number = 0;   
    name:string = '';
    phoneNumber:string = '';
    email:string = '';
    address:string = '';
    createDate: string = '';
    isActive : boolean = false;
}
