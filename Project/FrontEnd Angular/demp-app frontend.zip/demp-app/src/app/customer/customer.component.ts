import { Component, OnInit } from '@angular/core';
import { DatePipe } from '@angular/common';
import { CustomerService } from '../customer.service';
import { Subscription, timer } from 'rxjs';
import { map, share } from 'rxjs/operators';


@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit {

  //For date
  today = new Date();
  changedDate:any;
  pipe = new DatePipe('en-US');
  employees:any;
  title = "test"

  //For time
  time = new Date();
  rxTime = new Date();  
  intervalId:any;
  subscription: Subscription = new Subscription;

  //For greetings
  time_of_the_day = new Date(); 
  hours = this.time_of_the_day.getHours();
  greeting_text:string = "";

  constructor(private service:CustomerService) { }

  ngOnInit(): void {
    this.changeFormat(this.today);
    this.getCustomers();

    //For time
    this.intervalId = setInterval(() => {
      this.time = new Date();
    }, 1000);

    this.subscription = timer(0, 1000)
      .pipe(
        map(() => new Date()),
        share()
      )
      .subscribe(time => {
        this.rxTime = time;
      });

    this.greetingMessages();  
  }
  

  changeFormat(today:any){
    let ChangedFormat = this.pipe.transform(this.today, 'dd/MM/YYYY');   
    this.changedDate = "Today : "+ChangedFormat;
    console.log(this.changedDate);
  }

  getCustomers():void {
    this.service.getCustomers().subscribe(res =>{
      this.employees = res.data; 
      console.log("Customers",this.employees)
    });
  }  

  refresh(control:string){
    if(control == 'y')
        this.getCustomers()
  }

  ngOnDestroy() {
    clearInterval(this.intervalId);
    if (this.subscription) {
      this.subscription.unsubscribe();
    }
  }

  greetingMessages()
  {
    if(this.hours >=5 && this.hours <=11)
        this.greeting_text = "Good Morning!";
    else if (this.hours==12)     
        this.greeting_text = "Good Noon!";
    else if (this.hours>=13 && this.hours<=17)     
        this.greeting_text = "Good Afternoon!!";    
    else 
        this.greeting_text = "Good Evening!";
                    
  }

}
