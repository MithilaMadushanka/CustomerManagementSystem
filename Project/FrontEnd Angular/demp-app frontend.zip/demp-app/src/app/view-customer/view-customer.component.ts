import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { CustomerService } from '../customer.service';
import { Customer } from '../customer.model';
import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import { Validators, FormControl, FormGroup, FormBuilder } from '@angular/forms';



@Component({
  selector: 'app-view-customer',
  templateUrl: './view-customer.component.html',
  styleUrls: ['./view-customer.component.css']
})
export class ViewCustomerComponent implements OnInit {

  constructor(private service:CustomerService,private modalService: NgbModal, private fb:FormBuilder) { }
  @Output() newItemEvent = new EventEmitter<string>();
  
  employees:any;
  deleteEmployeeStatus:boolean =false;
  updateEmployeeStatus:boolean =false;
  customer: Customer = new Customer();
  closeResult = '';
  showAlert: boolean = true;

  employeeUpdateForm = new FormGroup({ 
    id: new FormControl(0),  
    name: new FormControl('',[Validators.required]),
    phoneNumber: new FormControl('',[Validators.required]),
    email: new FormControl('',[Validators.required,Validators.email]),
    address: new FormControl('',[Validators.required])
  });
  

  @Input() empList:any;

  mergedEmp : Customer[] = []
  empListCopy : Customer[] = []

  ngOnInit(): void {
  } 

  ngOnChanges() {       
    this.mergedEmp = this.empList
    this.empListCopy = this.empList
  }

  //For the CRUD operations
  removeCustomer(id:number){
    this.showAlert = true;
    this.service.deleteCustomer(id).subscribe((res) =>{      
      this.deleteEmployeeStatus = true;
      console.log("Customer Delete",res.status);     
      this.newItemEvent.emit("y");
    });
  }

  editCustomer(id:number){
     return this.service.getCustomer(id).subscribe(res =>{
       this.customer = res.data;
       console.log("Single Customer",this.customer);
     });
  }

  //For update the employee
  onSubmit(){   
    this.showAlert = true;
    console.log("UPDATE")
    this.service.updateCustomer(this.employeeUpdateForm.value).subscribe(res=>{
        console.log("Update Customer",res);        
        this.updateEmployeeStatus = true;       
        this.newItemEvent.emit("y");
    });
  }

  open(content: any,emp:Customer) {   
    this.fillTheUpdateFormValues(emp);
    this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {      
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

  fillTheUpdateFormValues(emp:Customer){
      this.employeeUpdateForm.patchValue({
        id:emp.id,
        name:emp.name,
        phoneNumber:emp.phoneNumber,
        email:emp.email,
        address:emp.address
      })
  }

  filter(event : Event){
    this.mergedEmp = this.empListCopy
    var text = (event.target as HTMLTextAreaElement).value
    if(text.length>1){
      var firstnameList = Object.assign([], this.empListCopy).filter(
        (item : Customer) => item.name.toLowerCase().indexOf(text.toLowerCase()) > -1
      )  
      var phone = Object.assign([], this.empListCopy).filter(
        (item : Customer) => item.phoneNumber.toLowerCase().indexOf(text.toLowerCase()) > -1
      )
      var emaillist = Object.assign([], this.empListCopy).filter(
        (item : Customer) => item.email.toLowerCase().indexOf(text.toLowerCase()) > -1
      )
      var addressList = Object.assign([], this.empListCopy).filter(
        (item : Customer) => item.address.toLowerCase().indexOf(text.toLowerCase()) > -1
      )
      var searchRes = firstnameList.concat(phone).concat(emaillist).concat(addressList);
      this.mergedEmp = searchRes.filter((item, pos) => searchRes.indexOf(item) === pos)

      
    }
  }

  hideAlert() {
    this.showAlert = false;
  }
  
}
