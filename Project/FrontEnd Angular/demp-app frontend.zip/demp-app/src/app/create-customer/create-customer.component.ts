import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { FormControl, FormBuilder, Validators } from '@angular/forms';
import { CustomerService } from '../customer.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-create-customer',
  templateUrl: './create-customer.component.html',
  styleUrls: ['./create-customer.component.css']
})
export class CreateCustomerComponent implements OnInit {

  constructor(private service:CustomerService, private fb:FormBuilder,private router:Router) { }
  @Output() newItemEvent = new EventEmitter<string>();

  emp:any;
  addCustomerSuccessStatus = 0;   
  showAlert: boolean = true;
  
  
  ngOnInit(): void {   
    
  }  

  customerForm = this.fb.group({ 
    id: new FormControl(0),  
    name: ['',Validators.required],
    phoneNumber: ['',Validators.required,Validators.pattern("/^\d{10}$/")],
    email: ['',Validators.required,Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$"),Validators.email],
    address: ['',Validators.required]
  });

  onSubmit(){
    this.showAlert = true;
    if(this.customerForm.invalid)
    {
      this.addCustomerSuccessStatus = 1;
    }
    else{
      this.customerForm.controls.id.setValue(0);
      this.service.addCustomer(this.customerForm.value).subscribe(res =>{      
      this.addCustomerSuccessStatus = 2;      
      this.resetForm();      
      this.newItemEvent.emit("y");     
      });  
    }      
  }  

 

  resetForm()
  {
      this.customerForm.reset();    
  }

  get primaryEmail() {
    return this.customerForm.get('email');
  }
     
  hideAlert() {
    this.showAlert = false;
  }
}
