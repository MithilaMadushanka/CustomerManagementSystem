﻿using Employee.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Customer.Models.Models;
using Microsoft.AspNetCore.Http;

namespace Customer.Repository.Interfaces
{
    public interface ICustomerRepository
    {
        Task<BaseResponse> Customer();
        Task<BaseResponse> SelectCustomerById(int id);
        Task<BaseResponse> InsertCustomer(CustomerDetailsRequest employee);
        Task<BaseResponse> UpdateCustomer(CustomerDetailsRequest employee);
        Task<BaseResponse> DeleteCustomer(int id);
        void SetRequest(HttpRequest httpRequest);
    }
}
