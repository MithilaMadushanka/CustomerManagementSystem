﻿using Dapper;
using Employee.Models;
using Customer.Models.Models;
using Customer.Repository.Interfaces;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Threading.Tasks;

namespace Customer.Repository
{
    public class CustomerRepository : ICustomerRepository
    {
        HttpRequest request;
        private readonly string _connection_string;

        public CustomerRepository(string connection_string)
        {
            _connection_string = connection_string;
        }

        public void SetRequest(HttpRequest httpRequest)
        {
            this.request = httpRequest;
        }

        public async Task<BaseResponse> SelectCustomerById(int id)
        {
            try
            {
                using (var connection = new SqlConnection(_connection_string))
                {
                    DynamicParameters para = new DynamicParameters();
                    para.Add("@CustomerId", id);
                    var results = await connection.QueryAsync<CustomerDetails>("[dbo].[SelectCustomerDetailById]", para, commandType: CommandType.StoredProcedure);
                    return new BaseResponseRepository().GetSuccessResponse(results);
                }
            }
            catch (SqlException ex) {
                return new BaseResponseRepository().GetErrorResponse(ex);
            }
            catch (Exception ex)
            {
                return new BaseResponseRepository().GetErrorResponse(ex);
            }
        }

        public async Task<BaseResponse> Customer()
        {
            try
            {
                using (var connection = new SqlConnection(_connection_string))
                {
                    DynamicParameters para = new DynamicParameters();
                    var results = await connection.QueryAsync<CustomerDetails>("[dbo].[SelectCustomerDetails]", para, commandType: CommandType.StoredProcedure);
                    return new BaseResponseRepository().GetSuccessResponse(results);
                }
            }
            catch (SqlException ex)
            {
                return new BaseResponseRepository().GetErrorResponse(ex);
            }
            catch (Exception ex)
            {
                return new BaseResponseRepository().GetErrorResponse(ex);                
            }
        }

        public async Task<BaseResponse> DeleteCustomer(int id)
        {
            try
            {
                using (var connection = new SqlConnection(_connection_string))
                {
                    DynamicParameters para = new DynamicParameters();
                    para.Add("@CustomerID", id);
                    var results = await connection.QueryAsync<CustomerDetailsRequest>("[dbo].[DeleteCustomerDetailsById]", para, commandType: CommandType.StoredProcedure);
                    return new BaseResponseRepository().GetSuccessResponse(results);
                }
            }
            catch (SqlException ex)
            {
                return new BaseResponseRepository().GetErrorResponse(ex);
            }

            catch (Exception ex)
            {
                return new BaseResponseRepository().GetErrorResponse(ex);
            }
        }        

        public async Task<BaseResponse> InsertCustomer(CustomerDetailsRequest employee)
        {
            try
            {
                using (var connection = new SqlConnection(_connection_string))
                {
                    DynamicParameters para = new DynamicParameters();
                    string JsonData = JsonConvert.SerializeObject(employee);
                    para.Add("@JsonData", JsonData, DbType.String);
                    para.Add("@Operation", "I", DbType.String);

                    var results = await connection.QueryAsync<CustomerDetailsRequest>("[dbo].[InsertCustomerDetail]", para, commandType: CommandType.StoredProcedure);
                    return new BaseResponseRepository().GetSuccessResponse(results);
                }
            }
            catch (SqlException ex)
            {
                return new BaseResponseRepository().GetErrorResponse(ex);
            }

            catch (Exception ex)
            {
                return new BaseResponseRepository().GetErrorResponse(ex);
            }
        }       

        public async Task<BaseResponse> UpdateCustomer(CustomerDetailsRequest employee)
        {
            try
            {
                using (var connection = new SqlConnection(_connection_string))
                {
                    DynamicParameters para = new DynamicParameters();
                    string JsonData = JsonConvert.SerializeObject(employee);
                    para.Add("@JsonData", JsonData, DbType.String);
                    para.Add("@Operation", "U", DbType.String);

                    var results = await connection.QueryAsync<CustomerDetailsRequest>("[dbo].[InsertCustomerDetail]", para, commandType: CommandType.StoredProcedure);
                    return new BaseResponseRepository().GetSuccessResponse(results);
                }
            }
            catch (SqlException ex)
            {
                return new BaseResponseRepository().GetErrorResponse(ex);
            }
            catch (Exception ex)
            {
                return new BaseResponseRepository().GetErrorResponse(ex);
            }
        }

       
    }
}
