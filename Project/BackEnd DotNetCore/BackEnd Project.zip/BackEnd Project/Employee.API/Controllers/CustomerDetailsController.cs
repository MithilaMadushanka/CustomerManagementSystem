﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Customer.Repository.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Customer.Models.Models;

namespace Employee.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomerController : ControllerBase
    {
        private ICustomerRepository _repository;

        public CustomerController(ICustomerRepository repository)
        {
            _repository = repository;
        }

        [HttpGet("GetCustomer")]
        public async Task<ActionResult> GetCustomer()
        {
            _repository.SetRequest(Request);
            var response = await _repository.Customer();

            if (response.Success)
                return Ok(response);
            else
                return StatusCode(StatusCodes.Status500InternalServerError,response.Message);
        }

        [HttpGet("SelectCustomerById")]
        public async Task<ActionResult> SelectCustomerById(int id)
        {
            _repository.SetRequest(Request);
            var response = await _repository.SelectCustomerById(id);

            if (response.Success)
                return Ok(response);
            else
                return StatusCode(StatusCodes.Status500InternalServerError, response.Message);
        }

        [HttpPost("InsertCustomer")]
        public async Task<ActionResult> InsertCustomer(CustomerDetailsRequest employee)
        {
            _repository.SetRequest(Request);
            var response = await _repository.InsertCustomer(employee);

            if (response.Success)
                return Ok(response);
            else
                return StatusCode(StatusCodes.Status500InternalServerError,response.Message);
        }

        [HttpPost("UpdateCustomer")]
        public async Task<ActionResult> UpdateCustomer(CustomerDetailsRequest employee)
        {
            _repository.SetRequest(Request);
            var response = await _repository.UpdateCustomer(employee);

            if (response.Success)
                return Ok(response);
            else
                return StatusCode(StatusCodes.Status500InternalServerError, response.Message);
        }

        [HttpDelete("DeleteCustomer")]
        public async Task<ActionResult> DeleteCustomer(int id)
        {
            _repository.SetRequest(Request);
            var responce = await _repository.DeleteCustomer(id);

            if (responce.Success)
                return Ok(responce);
            else
                return StatusCode(StatusCodes.Status500InternalServerError, responce.Message);
        }
    }
}